# test.py
print("Hello, world!")